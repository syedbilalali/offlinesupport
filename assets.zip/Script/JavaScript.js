﻿    if (document.getElementById("Chk_Cash").checked == true)
    {
        //document.getElementById("TextBox23").ReadOnly = false;
        document.body.bgColor = red;
    }